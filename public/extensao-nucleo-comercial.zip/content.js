/**
 * content.js — roda no contexto ISOLATED (acesso ao chrome.runtime).
 *
 * Escuta CustomEvents disparados pelo interceptor.js (MAIN world) e,
 * quando detecta um envio, extrai os dados do perfil do lead do DOM
 * e envia para o background registrar na planilha.
 */

;(function () {
  'use strict'

  if (window.__prospectAiContent) return
  window.__prospectAiContent = true

  // ── Contexto órfão ─────────────────────────────────────────────────────────
  // Ao recarregar ou atualizar a extensão, o Chrome invalida o contexto deste
  // script — mas não o remove das abas que já estavam abertas. O script velho
  // continua lá, com os observadores de DOM ativos, e toda chamada a `chrome.*`
  // passa a lançar "Extension context invalidated". Como observador de DOM
  // dispara a cada mudança de página, o erro se repete indefinidamente e
  // aparece na tela de erros da extensão como se fosse um defeito nela.
  //
  // Nada disso é recuperável de dentro da aba: a ligação com a extensão não
  // volta. O certo é perceber e desligar, deixando um recado de que basta
  // recarregar a aba.

  const observadores = []

  function contextoValido() {
    // `chrome.runtime.id` some justamente quando o contexto é invalidado.
    try {
      return Boolean(chrome.runtime?.id)
    } catch {
      return false
    }
  }

  function desligar(motivo) {
    for (const observador of observadores) observador.disconnect()
    observadores.length = 0
    console.info(
      '[Núcleo Comercial] Script desligado nesta aba (%s). Recarregue a página para voltar a capturar.',
      motivo,
    )
  }

  // ── Extração de dados do perfil ────────────────────────────────────────────

  /**
   * Tenta vários seletores em ordem até encontrar um que retorne texto.
   * Mais robusto que depender de um único class name do LinkedIn.
   */
  function queryText(...selectors) {
    for (const sel of selectors) {
      const el = document.querySelector(sel)
      const text = el?.textContent?.trim() || el?.getAttribute('aria-label')?.trim()
      if (text) return text
    }
    return ''
  }

  function parseHeadline(headline) {
    // Formatos comuns: "Cargo na Empresa" | "Cargo at Company" | "Cargo | Empresa"
    const seps = [' na ', ' at ', ' | ', ' - ', ' @ ', ' · ']
    for (const sep of seps) {
      const i = headline.indexOf(sep)
      if (i > 0) return [headline.slice(0, i).trim(), headline.slice(i + sep.length).trim()]
    }
    return [headline, '']
  }

  /**
   * Separadores em que o que vem **depois** é de fato a empresa.
   *
   * De propósito não inclui `|`, `·` nem `-`: com esses, a headline quase
   * sempre é uma lista de especialidades ("Vendas | B2C | SDR | Closer"), e o
   * trecho seguinte é outra especialidade, não empregador. Gravar isso na
   * coluna "Empresa contatada" é pior do que deixar em branco — um branco
   * qualquer um percebe e corrige; "B2C" no lugar da empresa passa batido e
   * contamina o funil.
   *
   * `da empresa` vem primeiro porque é o formato que o LinkedIn gera sozinho
   * em português quando a pessoa não escreveu uma headline própria.
   */
  const SEPARADORES_DE_EMPRESA = [
    ' da empresa ',
    ' na empresa ',
    ' at ',
    ' na ',
    ' @ ',
  ]

  function empresaDaHeadline(headline) {
    for (const sep of SEPARADORES_DE_EMPRESA) {
      const i = headline.indexOf(sep)
      if (i <= 0) continue
      const candidato = headline.slice(i + sep.length).trim()
      // " na " também aparece no meio de frase ("Especialista na área de
      // vendas"), e aí o que sobra é um pedaço de texto, não empregador.
      // Nome de empresa é curto; frase não é.
      if (candidato && candidato.length <= 60) return candidato
    }
    return ''
  }

  /**
   * Empresa atual pelo cartão do topo do perfil — é onde o LinkedIn mostra o
   * empregador como campo próprio, ao lado do logo, em vez de texto corrido.
   *
   * Prefere o `aria-label` ao texto visível: o rótulo de acessibilidade tem
   * formato estável ("Empresa atual: Inter. Clique para…") justamente porque
   * é contrato com leitor de tela, enquanto as classes e a posição do texto
   * mudam a cada redesenho da página.
   */
  function empresaDoCartaoDoTopo() {
    const alvo = document.querySelector(
      '[aria-label*="Empresa atual"], [aria-label*="Current company"], ' +
      '[aria-label*="empresa atual"], [aria-label*="current company"]',
    )
    const rotulo = alvo?.getAttribute('aria-label') ?? ''
    const casou = rotulo.match(/(?:Empresa atual|Current company):?\s*([^.]+)/i)
    if (casou?.[1]) return casou[1].trim()

    // O bloco fica à direita do nome, com o logo da empresa. As classes mudam
    // a cada redesenho, então tenta as conhecidas e, por último, o link para a
    // página da empresa — que é o que o logo sempre envolve.
    for (const sel of [
      '.pv-text-details__right-panel',
      '.pv-top-card--experience-list',
      'section[data-member-id] a[href*="/company/"]',
      'main a[href*="/company/"]',
    ]) {
      const el = document.querySelector(sel)
      const texto = el?.innerText?.trim().split('\n')[0]?.trim() ?? ''
      if (texto && texto.length <= 60) return texto
    }
    return ''
  }

  /**
   * O que a página oferecia quando a empresa não saiu.
   *
   * Vai junto da captura só nesse caso, e serve para consertar a leitura sem
   * depender de alguém abrir o console e me descrever o DOM. São dados
   * públicos do perfil (headline e rótulos de acessibilidade), truncados.
   */
  function diagnosticoDaEmpresa(headline) {
    const rotulos = [...document.querySelectorAll('[aria-label]')]
      .map((el) => el.getAttribute('aria-label') ?? '')
      .filter((r) => /empresa|company/i.test(r))
      .slice(0, 6)
      .map((r) => r.slice(0, 90))

    const linkDeEmpresa = document.querySelector('main a[href*="/company/"]')

    return {
      headline: (headline ?? '').slice(0, 140),
      rotulos,
      temPainelDireito: Boolean(document.querySelector('.pv-text-details__right-panel')),
      textoDoLinkDeEmpresa: (linkDeEmpresa?.innerText ?? '').trim().slice(0, 60),
    }
  }

  function extractProfileFromMessaging() {
    // Nome: link do perfil no header da conversa ativa
    const name = queryText(
      '.msg-entity-lockup__entity-title',
      '.msg-thread__link-to-profile .artdeco-entity-lockup__title',
      '[data-control-name="view_profile"] .artdeco-entity-lockup__title',
      '.msg-s-message-group__profile-link',
      '.msg-conversation-listitem__participant-names'
    )

    // Headline / cargo
    const headline = queryText(
      '.msg-entity-lockup__entity-info .msg-entity-lockup__entity-title + *',
      '.msg-thread__link-to-profile .artdeco-entity-lockup__subtitle',
      '.msg-entity-lockup__subtitle'
    )

    // URL do perfil
    const profileLink = (
      document.querySelector('.msg-thread__link-to-profile')?.href ||
      document.querySelector('a[href*="linkedin.com/in/"]')?.href ||
      ''
    )

    const [cargo, empresa] = parseHeadline(headline)
    return { nome: name, cargo, empresa, contato: profileLink }
  }

  // Extrai dados do JSON-LD que o LinkedIn injeta para SEO
  // Ex: { "@type": "Person", "name": "...", "jobTitle": "...", "worksFor": { "name": "..." } }
  function extractFromJsonLd() {
    const scripts = document.querySelectorAll('script[type="application/ld+json"]')
    for (const script of scripts) {
      try {
        const data = JSON.parse(script.textContent)
        // O LinkedIn empacota os nós num `@graph`; as outras duas formas são
        // de versões anteriores da página e continuam aqui porque custam nada.
        const person = data?.['@type'] === 'Person' ? data
          : data?.mainEntity?.['@type'] === 'Person' ? data.mainEntity
          : Array.isArray(data?.['@graph'])
            ? data['@graph'].find((no) => no?.['@type'] === 'Person')
            : null
        if (!person) continue
        const nome = person.name ?? ''
        const cargo = typeof person.jobTitle === 'string' ? person.jobTitle
          : Array.isArray(person.jobTitle) ? (person.jobTitle[0] ?? '') : ''
        const empresaBruta = Array.isArray(person.worksFor) ? person.worksFor[0] : person.worksFor
        const empresa = empresaBruta?.name ?? person.affiliation?.name ?? ''
        if (nome) {
          console.log('[Núcleo Comercial] JSON-LD encontrado:', { nome, cargo, empresa })
          return { nome, cargo, empresa }
        }
      } catch { /* JSON inválido */ }
    }
    return null
  }

  function extractProfileFromProfilePage() {
    // Página /in/* — o perfil é o próprio conteúdo da página

    // Abordagem 0: JSON-LD (mais confiável — dados estruturados para SEO)
    // Não devolve na hora: o JSON-LD costuma trazer o nome sem `worksFor`, e
    // sair aqui deixava a empresa vazia sem sequer tentar as outras pistas —
    // era o que descartava a captura inteira lá no CRM.
    const jsonLd = extractFromJsonLd()

    // ── Nome ─────────────────────────────────────────────────────────────────
    // LinkedIn NÃO usa h1 — nome vem do og:title ou título da aba

    let name = jsonLd?.nome ?? ''

    if (!name) name = queryText(
      // Tenta DOM mesmo assim (pode mudar no futuro)
      'h1', 'h2.text-heading-xlarge', '.pv-top-card--list h1'
    )

    if (!name) {
      const og = document.querySelector('meta[property="og:title"]')?.content ?? ''
      const ogMatch = og.match(/^(.+?)\s*[|–\-]\s*LinkedIn/i)
      name = ogMatch?.[1]?.trim() ?? ''
      if (name) console.log('[Núcleo Comercial] Nome via og:title:', name)
    }

    if (!name) {
      const titleMatch = document.title.match(/^\(\d+\)\s*(.+?)\s*[|–\-]\s*LinkedIn/i)
        ?? document.title.match(/^(.+?)\s*[|–\-]\s*LinkedIn/i)
      name = titleMatch?.[1]?.trim() ?? ''
      if (name) console.log('[Núcleo Comercial] Nome via page title:', name)
    }

    // ── Headline / Cargo via body.innerText ──────────────────────────────────
    // O LinkedIn renderiza o nome e a headline como texto simples no DOM,
    // sem h1 nem classes estáveis. Localizamos o nome no innerText e pegamos
    // o bloco de texto logo abaixo.
    let headline = queryText(
      '.text-body-medium.break-words',
      '.ph5 .text-body-medium',
      '.pv-top-card--list .text-body-medium',
      '.pv-text-details__left-panel .text-body-medium'
    )

    if (!headline && name) {
      const bodyText = document.body.innerText ?? ''
      // Remove credenciais do nome para a busca (ex: "Kleber, CEA" → "Kleber")
      const searchName = name.split(/[,·]/)[0].trim()
      const idx = bodyText.indexOf(searchName)
      if (idx !== -1) {
        const after = bodyText.slice(idx + searchName.length)
        const lines = after.split('\n')
          .map(l => l.trim())
          .filter(l => l.length > 5 && !l.match(/^[·•·]\s*\d/)) // ignora "· 3º"
        headline = lines[0] ?? ''
        if (headline) console.log('[Núcleo Comercial] Headline via body text:', headline)
      }
    }

    // Cargo = primeira parte da headline (antes do primeiro separador)
    const cargo = jsonLd?.cargo || headline.split(/\s*[|·]\s*/)[0].trim()

    // ── Empresa ──────────────────────────────────────────────────────────────
    // Em cascata, da pista mais confiável para a mais frágil. Cada uma falha
    // por um motivo diferente, e nenhuma sozinha cobre todo perfil: há quem
    // não tenha empresa atual, quem escreva a headline como lista de
    // especialidades, e perfil cuja seção Experiência nem carregou ainda.
    let empresa = jsonLd?.empresa ?? ''
    let origemDaEmpresa = empresa ? 'json-ld' : ''

    if (!empresa) {
      empresa = empresaDoCartaoDoTopo()
      if (empresa) origemDaEmpresa = 'cartão do topo'
    }

    // 2ª linha não-vazia após "Experiência" (1ª é o cargo, 2ª é a empresa).
    // Formato LinkedIn: Cargo\nEmpresa · Tipo\nData\nLocal
    if (!empresa) {
      const bodyText2 = document.body.innerText ?? ''
      const expBlock = bodyText2.match(/(?:Experiência|Experience)\s*\n([\s\S]{0,600})/)
      if (expBlock) {
        const lines = expBlock[1].split('\n')
          .map(l => l.trim())
          .filter(l => l.length > 2 && !/^\d{1,2}\s+de\b/i.test(l) && !/^(jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez|feb|apr|may|aug|sep|oct|dec)/i.test(l))
        empresa = (lines[1] ?? '').split(/\s*·\s*/)[0].trim()
        if (empresa) origemDaEmpresa = 'seção Experiência'
      }
    }

    if (!empresa) {
      empresa = empresaDaHeadline(headline)
      if (empresa) origemDaEmpresa = 'headline'
    }

    console.log('[Núcleo Comercial] Extração final:', {
      nome: name, cargo, empresa, origemDaEmpresa, headline,
    })

    return {
      nome: name,
      cargo,
      empresa,
      contato: window.location.href,
      ...(empresa ? {} : { diagnostico: diagnosticoDaEmpresa(headline) }),
    }
  }

  function extractProfile() {
    const path = window.location.pathname
    if (path.startsWith('/messaging')) return extractProfileFromMessaging()
    return extractProfileFromProfilePage()
  }

  // ── Debounce: evita disparar múltiplas vezes por ação ─────────────────────

  let lastSent = 0
  const DEBOUNCE_MS = 3000

  function dispatch(eventData) {
    if (!contextoValido()) {
      desligar('a extensão foi recarregada ou atualizada')
      return
    }

    const now = Date.now()
    if (now - lastSent < DEBOUNCE_MS) return
    lastSent = now

    const profile = extractProfile()
    if (!profile.nome) {
      console.warn('[Núcleo Comercial] Perfil não encontrado no DOM.', { path: window.location.pathname })
      return
    }

    const payload = {
      ...profile,
      canal: 'LinkedIn',
      timestamp: new Date().toISOString(),
      pageUrl: window.location.href,
      trigger: eventData.type,
    }

    console.log('[Núcleo Comercial] Prospecção detectada:', payload)

    try {
      chrome.runtime.sendMessage({ type: 'PROSPECCAO_DETECTADA', payload })
    } catch (erro) {
      // A checagem acima cobre o caso comum, mas o contexto pode cair entre
      // ela e o envio — a captura desta vez se perde de qualquer jeito.
      desligar(erro?.message ?? 'falha ao falar com a extensão')
    }
  }

  // ── Escuta postMessage do interceptor.js (MAIN → ISOLATED) ───────────────
  // window.postMessage cruza a barreira de mundos de forma garantida no MV3.

  window.addEventListener('message', (e) => {
    if (e.source !== window) return
    if (!e.data?.__prospectai) return

    const { type } = e.data
    if (type === 'message-sent') {
      setTimeout(() => dispatch({ type: 'prospectai:message-sent' }), 500)
    } else if (type === 'connection-sent') {
      setTimeout(() => dispatch({ type: 'prospectai:connection-sent' }), 500)
    }
  })

  // ── Detecção via DOM: botão "Conectar" → "Pendente" ───────────────────────
  // Fallback para quando o LinkedIn muda o endpoint da API.
  // Quando o botão muda para "Pendente"/"Pending", a conexão foi confirmada.
  ;(function setupConnectionObserver() {
    // Registra botões que já estão "Pendente" ao carregar (não são novos)
    const alreadyPending = new Set(
      [...document.querySelectorAll('button')].filter(b =>
        /pendente|pending/i.test(b.textContent.trim())
      )
    )

    const observer = new MutationObserver(() => {
      const pendingBtns = [...document.querySelectorAll('button')].filter(b =>
        /pendente|pending/i.test(b.textContent.trim())
      )
      for (const btn of pendingBtns) {
        if (!alreadyPending.has(btn)) {
          alreadyPending.add(btn)
          console.log('[Núcleo Comercial] Botão Pendente detectado via DOM — conexão enviada!')
          dispatch({ type: 'prospectai:connection-sent' })
        }
      }
    })

    observer.observe(document.body, { childList: true, subtree: true })
    observadores.push(observer)
  })()

  // ── Detecção de respostas e conexões aceitas ──────────────────────────────
  // Observa o DOM do LinkedIn para detectar notificações e mensagens recebidas.
  // Quando detectado, envia STATUS_UPDATE_BY_NAME para o background atualizar a planilha.
  ;(function setupStatusObserver() {
    let lastStatusDispatch = 0
    const STATUS_DEBOUNCE_MS = 8000
    const seenKeys = new Set()

    function dispatchStatusUpdate(nome, status) {
      const now = Date.now()
      if (now - lastStatusDispatch < STATUS_DEBOUNCE_MS) return
      lastStatusDispatch = now
      console.log('[Núcleo Comercial] Status update detectado:', { nome, status })
    }

    function checkNotifications() {
      // Painel de notificações do LinkedIn — detecta conexão aceita ou mensagem recebida
      const candidates = document.querySelectorAll(
        '[data-notification-urn], .nt-card__text, .notification-card'
      )
      for (const el of candidates) {
        const key = el.getAttribute('data-notification-urn') ?? el.textContent?.trim().slice(0, 60)
        if (!key || seenKeys.has(key)) continue
        seenKeys.add(key)

        const text = el.textContent?.trim() ?? ''
        const connectionAccepted = /aceitou seu convite|accepted your invitation|conectou com você/i.test(text)
        const messageReceived = /enviou uma mensagem|sent you a message|respondeu à sua mensagem/i.test(text)
        if (!connectionAccepted && !messageReceived) continue

        // Extrai o nome: tenta elementos específicos, depois regex no texto
        const nameEl = el.querySelector('.t-bold, strong, .artdeco-entity-lockup__title, h3, [data-control-name="view_profile"]')
        let nome = nameEl?.textContent?.trim() ?? ''
        if (!nome) {
          const m = text.match(/^(.+?)\s+(?:aceitou|accepted|enviou|sent|conectou)/i)
          nome = m?.[1]?.trim() ?? ''
        }
        if (nome) dispatchStatusUpdate(nome, 'Respondeu')
      }
    }

    function checkInboundMessages() {
      if (!window.location.pathname.startsWith('/messaging')) return
      // Mensagens recebidas: grupo de mensagens não enviadas pelo usuário
      const inbound = document.querySelectorAll(
        '.msg-s-message-group--received:not([data-pai-seen])'
      )
      if (!inbound.length) return
      inbound[0].setAttribute('data-pai-seen', '1')

      const senderName = document.querySelector(
        '.msg-entity-lockup__entity-title, .msg-thread__link-to-profile .artdeco-entity-lockup__title'
      )?.textContent?.trim() ?? ''
      if (senderName) dispatchStatusUpdate(senderName, 'Respondeu')
    }

    const statusObserver = new MutationObserver(() => {
      checkNotifications()
      checkInboundMessages()
    })
    statusObserver.observe(document.body, { childList: true, subtree: true })
    observadores.push(statusObserver)
  })()

  // ── Botão de teste manual no popup ────────────────────────────────────────

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === 'DEBUG_EXTRACT') {
      const profile = extractProfile()
      sendResponse({ profile, url: window.location.href })
    }
    return true
  })

  console.log('[Núcleo Comercial] Content script ativo.', window.location.pathname)
})()
